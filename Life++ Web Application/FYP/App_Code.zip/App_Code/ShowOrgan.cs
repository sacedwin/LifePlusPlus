﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ShowOrgan
/// </summary>
public class ShowOrgan
{
	public string DOID { get; set; }
	public string Donor { get; set; }
	public string OrganType { get; set; }
	public string Receiver { get; set; }
	public string hospitalRefNum { get; set; }
}