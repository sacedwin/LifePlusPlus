﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for FacebookUser
/// </summary>
public class FacebookUser
{
        public string Id { get; set; }
        public string Name { get; set; }
        public string UserName { get; set; }
        public string PictureUrl { get; set; }
        public string Email { get; set; }
        public string Gender { get; set; }

	public FacebookUser()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}