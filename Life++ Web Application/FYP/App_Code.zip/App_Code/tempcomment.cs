﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for tempcomment
/// </summary>
public class tempcomment
{
	public string comentID { get; set; }
	public string comment { get; set; }
	public string commentby { get; set; }
	public DateTime time { get; set; }
	public string timeshow { get; set; }
	public string status { get; set; }
} 